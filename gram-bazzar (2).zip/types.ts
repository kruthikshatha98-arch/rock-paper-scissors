export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  unit: string;
  image: string;
  description: string;
  distributorId: string;
  isFeatured?: boolean;
  bulkThreshold?: number; // Minimum quantity for discount
  bulkPrice?: number;     // Discounted price per unit
}

export interface Distributor {
  id: string;
  name: string;
  phone: string;
  location: string;
  rating: number;
  specialty: string;
  isOnline: boolean;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export type ViewState = 'marketplace' | 'distributors';