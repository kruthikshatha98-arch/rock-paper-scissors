import React, { useState, useMemo } from 'react';
import { INITIAL_DISTRIBUTORS, PRODUCTS } from './constants';
import { Distributor, Product, CartItem, ViewState } from './types';
import { ShoppingCartIcon, PlusIcon, PhoneIcon, StarIcon, StoreIcon, UsersIcon, XIcon, SearchIcon, FilterIcon, RupeeIcon, ChevronDownIcon, EditIcon } from './components/Icons';
import { AIChef } from './components/AIChef';

// Extracted ProductCard for reuse
const ProductCard = ({ product, distributors, onAdd }: { product: Product, distributors: Distributor[], onAdd: (p: Product, qty?: number) => void }) => {
  const hasBulkOffer = product.bulkThreshold && product.bulkPrice;
  const savings = hasBulkOffer ? Math.round(((product.price - product.bulkPrice!) / product.price) * 100) : 0;

  return (
    <div className="bg-white rounded-2xl overflow-hidden border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-300 group flex flex-col h-full hover:border-orange-200">
      <div className="relative h-48 overflow-hidden bg-white p-4">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-contain transform group-hover:scale-110 transition-transform duration-500"
        />
        <div className="absolute top-3 right-3 flex flex-col gap-1 items-end">
          <div className="bg-white/95 backdrop-blur-sm px-3 py-1.5 rounded-full text-sm font-bold text-orange-700 shadow-sm border border-orange-100 flex items-center">
            <RupeeIcon className="w-3 h-3 mr-0.5" />
            {product.price} <span className="text-[10px] text-slate-500 font-normal ml-1">/{product.unit}</span>
          </div>
          {hasBulkOffer && (
            <div className="bg-green-600 text-white px-2 py-0.5 rounded-full text-[10px] font-bold shadow-sm">
              Save {savings}%
            </div>
          )}
        </div>
      </div>
      <div className="p-5 flex-1 flex flex-col bg-slate-50/30">
        <div className="mb-2">
              <p className="text-[10px] font-bold text-orange-600 uppercase tracking-wider mb-1">{product.category}</p>
              <h3 className="font-bold text-lg text-slate-900 leading-tight">{product.name}</h3>
        </div>
        <p className="text-sm text-slate-600 mb-4 line-clamp-2">{product.description}</p>
        
        {hasBulkOffer && (
          <div className="mb-4 bg-orange-100/50 p-2 rounded-lg border border-orange-100">
            <p className="text-xs font-semibold text-orange-800 flex items-center gap-1">
              <StarIcon className="w-3 h-3 fill-orange-500 text-orange-500" />
              Bulk Deal: Buy {product.bulkThreshold}+
            </p>
            <p className="text-xs text-orange-700 mt-0.5">
              Get at <span className="font-bold">₹{product.bulkPrice}</span>/{product.unit}
            </p>
          </div>
        )}

        <div className="mt-auto pt-4 border-t border-slate-100 flex items-center justify-between gap-2">
          <div className="flex flex-col">
              <span className="text-[10px] text-slate-400 font-medium uppercase">Sold by</span>
              <span className="text-xs font-semibold text-slate-700 truncate max-w-[100px]">{distributors.find(d => d.id === product.distributorId)?.name}</span>
          </div>
          <div className="flex items-center gap-1">
             {hasBulkOffer && (
               <button 
                onClick={(e) => {
                  e.stopPropagation();
                  onAdd(product, product.bulkThreshold);
                }}
                className="px-2 py-2 bg-orange-100 text-orange-700 rounded-xl hover:bg-orange-200 transition-colors text-xs font-bold"
                title={`Add ${product.bulkThreshold} items for bulk price`}
              >
                Buy {product.bulkThreshold}+
              </button>
             )}
            <button 
              onClick={(e) => {
                e.stopPropagation();
                onAdd(product);
              }}
              className="flex items-center gap-1.5 bg-slate-900 text-white px-3 py-2 rounded-xl hover:bg-orange-600 active:scale-95 transition-all shadow-md hover:shadow-orange-500/30 group-hover:bg-orange-600"
              title="Add to Cart"
            >
              <PlusIcon className="w-4 h-4" />
              <span className="text-sm font-semibold">Add</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>('marketplace');
  const [distributors, setDistributors] = useState<Distributor[]>(INITIAL_DISTRIBUTORS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [showAddDistributor, setShowAddDistributor] = useState(false);
  
  // Edit Distributor State
  const [editingDistributor, setEditingDistributor] = useState<Distributor | null>(null);
  const [editForm, setEditForm] = useState({ name: '', phone: '', location: '', specialty: '' });
  
  // Grocery Store Logic
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedDistributorId, setSelectedDistributorId] = useState<string>('All');
  const [priceRange, setPriceRange] = useState<string>('All');
  const [showOfflineModal, setShowOfflineModal] = useState(false);

  // Cart Filter Logic
  const [cartSearchQuery, setCartSearchQuery] = useState('');
  const [cartDistributorFilter, setCartDistributorFilter] = useState('All');

  // New Distributor Form State
  const [newDistName, setNewDistName] = useState('');
  const [newDistPhone, setNewDistPhone] = useState('');
  const [newDistLocation, setNewDistLocation] = useState('');
  const [newDistSpecialty, setNewDistSpecialty] = useState('');

  const addToCart = (product: Product, quantity: number = 1) => {
    setCart((prev) => {
      const existing = prev.find(p => p.id === product.id);
      if (existing) {
        return prev.map(p => p.id === product.id ? { ...p, quantity: p.quantity + quantity } : p);
      }
      return [...prev, { ...product, quantity }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, quantity: Math.max(1, item.quantity + delta) };
      }
      return item;
    }));
  };

  const setItemQuantity = (id: string, qty: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        return { ...item, quantity: Math.max(1, qty) };
      }
      return item;
    }));
  };

  const handleAddDistributor = (e: React.FormEvent) => {
    e.preventDefault();
    if (distributors.length >= 10) {
      alert("Bazzar limit reached (10 distributors max).");
      return;
    }
    const newDistributor: Distributor = {
      id: `d${Date.now()}`,
      name: newDistName,
      phone: newDistPhone,
      location: newDistLocation,
      specialty: newDistSpecialty || "General",
      rating: 5.0, // New distributors start with 5 stars
      isOnline: false
    };
    setDistributors([...distributors, newDistributor]);
    setShowAddDistributor(false);
    // Reset form
    setNewDistName('');
    setNewDistPhone('');
    setNewDistLocation('');
    setNewDistSpecialty('');
  };

  const openEditModal = (dist: Distributor) => {
    setEditingDistributor(dist);
    setEditForm({
      name: dist.name,
      phone: dist.phone,
      location: dist.location,
      specialty: dist.specialty,
    });
  };

  const handleUpdateDistributor = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDistributor) return;

    setDistributors(prev => prev.map(d => 
      d.id === editingDistributor.id 
        ? { ...d, name: editForm.name, phone: editForm.phone, location: editForm.location, specialty: editForm.specialty } 
        : d
    ));
    setEditingDistributor(null);
  };

  const resetAllFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedDistributorId('All');
    setPriceRange('All');
  };

  // Helper to determine active price based on quantity
  const getItemPrice = (item: CartItem) => {
    if (item.bulkThreshold && item.bulkPrice && item.quantity >= item.bulkThreshold) {
      return item.bulkPrice;
    }
    return item.price;
  };

  // Grocery Store Computed Values
  const categories = useMemo(() => ['All', ...Array.from(new Set(PRODUCTS.map(p => p.category)))], []);

  const featuredProducts = useMemo(() => PRODUCTS.filter(p => p.isFeatured), []);

  const filteredProducts = PRODUCTS.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    
    // Distributor Filter
    const matchesDistributor = selectedDistributorId === 'All' || p.distributorId === selectedDistributorId;

    // Price Filter
    let matchesPrice = true;
    if (priceRange === 'Under ₹50') matchesPrice = p.price < 50;
    else if (priceRange === '₹50 - ₹200') matchesPrice = p.price >= 50 && p.price <= 200;
    else if (priceRange === '₹200 - ₹500') matchesPrice = p.price > 200 && p.price <= 500;
    else if (priceRange === 'Above ₹500') matchesPrice = p.price > 500;

    return matchesSearch && matchesCategory && matchesDistributor && matchesPrice;
  });

  // Cart Filtering Computed Values
  const cartDistributors = useMemo(() => {
    const distIds = new Set(cart.map(item => item.distributorId));
    return distributors.filter(d => distIds.has(d.id));
  }, [cart, distributors]);

  const filteredCartItems = cart.filter(item => {
     const matchesSearch = item.name.toLowerCase().includes(cartSearchQuery.toLowerCase());
     const matchesDist = cartDistributorFilter === 'All' || item.distributorId === cartDistributorFilter;
     return matchesSearch && matchesDist;
  });

  const cartTotal = cart.reduce((sum, item) => sum + (getItemPrice(item) * item.quantity), 0);

  // Group items by distributor for offline calling
  const cartByDistributor = useMemo(() => {
    const groups: { [key: string]: { distributor: Distributor | undefined, items: CartItem[], total: number } } = {};
    cart.forEach(item => {
      if (!groups[item.distributorId]) {
        groups[item.distributorId] = {
          distributor: distributors.find(d => d.id === item.distributorId),
          items: [],
          total: 0
        };
      }
      groups[item.distributorId].items.push(item);
      groups[item.distributorId].total += getItemPrice(item) * item.quantity;
    });
    return groups;
  }, [cart, distributors]);

  return (
    <div className="min-h-screen bg-orange-50 font-sans text-slate-900 pb-20">
      
      {/* --- Header --- */}
      <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-orange-100 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 cursor-pointer shrink-0" onClick={() => setView('marketplace')}>
            <div className="bg-orange-600 text-white p-2 rounded-xl shadow-orange-200 shadow-lg">
              <StoreIcon className="w-6 h-6" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold tracking-tight text-slate-900 leading-none">Gram<span className="text-orange-600">Bazzar</span></span>
              <span className="text-[10px] text-slate-500 font-medium tracking-wide">WHOLESALE & RETAIL</span>
            </div>
          </div>

          {/* Desktop Search */}
          <div className="hidden md:flex flex-1 max-w-xl mx-8">
            <div className="relative w-full group">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <SearchIcon className="h-5 w-5 text-slate-400 group-focus-within:text-orange-600 transition-colors" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setView('marketplace'); }}
                className="block w-full pl-11 pr-4 py-3 bg-slate-100 border-none rounded-full text-sm focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all placeholder:text-slate-400"
                placeholder="Search Dal, Rice, Atta..."
              />
            </div>
          </div>
          
          <nav className="hidden md:flex items-center gap-1">
            <button 
              onClick={() => setView('marketplace')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${view === 'marketplace' ? 'bg-orange-50 text-orange-700' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'}`}
            >
              Marketplace
            </button>
            <button 
              onClick={() => setView('distributors')}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${view === 'distributors' ? 'bg-orange-50 text-orange-700' : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'}`}
            >
              Distributors
            </button>
          </nav>

          <div className="flex items-center gap-2">
             <button 
              onClick={() => setIsCartOpen(true)}
              className="relative p-3 text-slate-600 hover:bg-orange-50 hover:text-orange-700 rounded-full transition-colors group"
            >
              <ShoppingCartIcon className="w-6 h-6 group-hover:scale-105 transition-transform" />
              {cart.length > 0 && (
                <span className="absolute top-1 right-1 min-w-[20px] h-5 px-1 bg-red-600 text-white text-[10px] font-bold flex items-center justify-center rounded-full ring-2 ring-white animate-in zoom-in">
                  {cart.length}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mobile Search (visible only on small screens) */}
        <div className="md:hidden px-4 pb-4">
           <div className="relative w-full">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <SearchIcon className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => { setSearchQuery(e.target.value); setView('marketplace'); }}
                className="block w-full pl-10 pr-4 py-2.5 bg-slate-100 border-none rounded-xl text-sm focus:ring-2 focus:ring-orange-500 focus:bg-white transition-all"
                placeholder="Search Dal, Atta..."
              />
            </div>
        </div>
      </header>

      {/* --- Main Content --- */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {view === 'marketplace' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            
            {/* Filter Section */}
            <div className="flex flex-col gap-4">
                {/* Row 1: Categories */}
                <div className="flex items-center gap-2 overflow-x-auto pb-2 no-scrollbar -mx-4 px-4 sm:mx-0 sm:px-0">
                   <div className="flex items-center gap-2 pr-4">
                      <div className="p-2 bg-white border border-slate-200 rounded-lg text-slate-400 hidden sm:block">
                         <FilterIcon className="w-4 h-4" />
                      </div>
                      {categories.map(cat => (
                        <button
                          key={cat}
                          onClick={() => setSelectedCategory(cat)}
                          className={`whitespace-nowrap px-5 py-2.5 rounded-full text-sm font-semibold transition-all duration-200 border ${
                            selectedCategory === cat 
                              ? 'bg-orange-600 text-white border-orange-600 shadow-md shadow-orange-200' 
                              : 'bg-white text-slate-600 border-slate-200 hover:border-orange-200 hover:text-orange-600 hover:bg-orange-50'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                   </div>
                </div>

                {/* Row 2: Advanced Filters (Distributor & Price) */}
                <div className="flex flex-wrap gap-3 items-center">
                    {/* Distributor Select */}
                    <div className="relative group">
                        <select 
                            value={selectedDistributorId}
                            onChange={(e) => setSelectedDistributorId(e.target.value)}
                            className="appearance-none w-full sm:w-auto bg-white border border-slate-200 text-slate-700 py-2.5 pl-4 pr-10 rounded-xl focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 cursor-pointer font-medium text-sm shadow-sm hover:border-orange-300 transition-all"
                        >
                            <option value="All">All Distributors</option>
                            {distributors.map(d => (
                                <option key={d.id} value={d.id}>{d.name}</option>
                            ))}
                        </select>
                        <ChevronDownIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none group-hover:text-orange-500 transition-colors" />
                    </div>

                    {/* Price Range Select */}
                    <div className="relative group">
                         <select 
                            value={priceRange}
                            onChange={(e) => setPriceRange(e.target.value)}
                            className="appearance-none w-full sm:w-auto bg-white border border-slate-200 text-slate-700 py-2.5 pl-4 pr-10 rounded-xl focus:outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 cursor-pointer font-medium text-sm shadow-sm hover:border-orange-300 transition-all"
                         >
                            <option value="All">All Prices</option>
                            <option value="Under ₹50">Under ₹50</option>
                            <option value="₹50 - ₹200">₹50 - ₹200</option>
                            <option value="₹200 - ₹500">₹200 - ₹500</option>
                            <option value="Above ₹500">Above ₹500</option>
                         </select>
                         <ChevronDownIcon className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none group-hover:text-orange-500 transition-colors" />
                    </div>

                    {/* Reset Button */}
                    {(selectedDistributorId !== 'All' || priceRange !== 'All' || selectedCategory !== 'All' || searchQuery) && (
                        <button 
                            onClick={resetAllFilters} 
                            className="text-sm text-slate-500 hover:text-red-600 font-semibold px-3 py-2 transition-colors flex items-center gap-1"
                        >
                            <XIcon className="w-3 h-3" />
                            Reset Filters
                        </button>
                    )}
                </div>
            </div>

            {/* Featured Products Section - Only visible on Home (No Filters) */}
            {!searchQuery && selectedCategory === 'All' && selectedDistributorId === 'All' && priceRange === 'All' && featuredProducts.length > 0 && (
               <section className="mb-8 animate-in slide-in-from-bottom-4 duration-700">
                 <div className="flex items-center gap-2 mb-5 px-1">
                   <div className="bg-yellow-100 p-2 rounded-lg text-yellow-700 shadow-sm">
                     <StarIcon className="w-5 h-5" fill={true} />
                   </div>
                   <h2 className="text-xl font-bold text-slate-900 tracking-tight">Featured Today</h2>
                   <span className="text-xs font-semibold text-yellow-700 bg-yellow-50 px-2 py-1 rounded-full border border-yellow-100">Top Picks</span>
                 </div>
                 <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                   {featuredProducts.map(product => (
                     <ProductCard 
                       key={product.id} 
                       product={product} 
                       distributors={distributors} 
                       onAdd={addToCart} 
                     />
                   ))}
                 </div>
                 <div className="w-full h-px bg-slate-100 mt-10"></div>
               </section>
            )}

            {/* Product Grid */}
            <div>
              <div className="flex justify-between items-end mb-6">
                <h2 className="text-2xl font-bold text-slate-900">
                  {searchQuery ? `Results for "${searchQuery}"` : selectedCategory === 'All' ? 'In Stock Now' : selectedCategory}
                </h2>
                <span className="text-sm text-slate-500 font-medium">{filteredProducts.length} items</span>
              </div>
              
              {filteredProducts.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  {filteredProducts.map(product => (
                    <ProductCard 
                      key={product.id} 
                      product={product} 
                      distributors={distributors} 
                      onAdd={addToCart} 
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-20 bg-white rounded-3xl border border-slate-100 border-dashed">
                  <div className="inline-flex p-4 bg-orange-50 rounded-full mb-4">
                    <SearchIcon className="w-8 h-8 text-orange-300" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900">No products found</h3>
                  <p className="text-slate-500 mt-1">Try adjusting your filters or search terms.</p>
                  <button onClick={resetAllFilters} className="mt-4 text-orange-600 font-medium hover:underline">Clear all filters</button>
                </div>
              )}
            </div>
          </div>
        )}

        {view === 'distributors' && (
          <div className="space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
             <div className="bg-gradient-to-r from-orange-800 to-orange-700 rounded-3xl p-8 md:p-12 text-white relative overflow-hidden shadow-2xl mb-10">
                <div className="relative z-10 max-w-2xl">
                  <h2 className="text-3xl md:text-4xl font-bold mb-4">Connect with Gram Bazzar Wholesalers</h2>
                  <p className="text-orange-100 text-lg mb-8">Directly support local businesses. Call to order or browse their catalog online.</p>
                  <button 
                    onClick={() => setShowAddDistributor(true)}
                    className="flex items-center gap-2 bg-white text-orange-800 px-6 py-3 rounded-xl font-bold hover:bg-orange-50 transition-colors shadow-lg"
                  >
                    <UsersIcon className="w-5 h-5" />
                    Register as Distributor
                  </button>
                </div>
                <div className="absolute right-0 top-0 h-full w-1/3 bg-gradient-to-l from-white/10 to-transparent pointer-events-none"></div>
                <StoreIcon className="absolute -right-10 -bottom-10 w-64 h-64 text-white/10 rotate-12" />
             </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {distributors.map(dist => (
                <div key={dist.id} className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm hover:border-orange-200 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group">
                  <div className="flex justify-between items-start mb-4">
                    <div className="w-12 h-12 bg-orange-50 rounded-xl flex items-center justify-center text-orange-600">
                      <StoreIcon className="w-6 h-6" />
                    </div>
                    <div className="flex gap-2">
                        <div className="flex items-center gap-1 bg-yellow-50 text-yellow-700 px-2.5 py-1 rounded-lg text-sm font-bold">
                        <StarIcon className="w-4 h-4" fill={true} />
                        {dist.rating}
                        </div>
                        <button 
                            onClick={() => openEditModal(dist)}
                            className="p-1.5 text-slate-400 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-colors"
                            title="Edit Distributor"
                        >
                            <EditIcon className="w-4 h-4" />
                        </button>
                    </div>
                  </div>
                  <h3 className="font-bold text-xl text-slate-900 mb-1">{dist.name}</h3>
                  <p className="text-sm text-orange-600 font-medium mb-3 bg-orange-50 inline-block px-2 py-0.5 rounded-md">{dist.specialty}</p>
                  
                  <div className="space-y-3 text-sm text-slate-500 mb-6 border-t border-slate-100 pt-4">
                    <div className="flex items-center justify-between gap-2 p-2 rounded-lg hover:bg-slate-50 transition-colors">
                       <div className="flex items-center gap-2">
                           <PhoneIcon className="w-4 h-4 text-slate-400" />
                           <span className="font-medium text-slate-700">{dist.phone}</span>
                       </div>
                       <a href={`tel:${dist.phone}`} className="text-xs bg-green-100 text-green-700 px-2.5 py-1.5 rounded-md font-bold hover:bg-green-200 transition-colors flex items-center gap-1">
                          <PhoneIcon className="w-3 h-3" />
                          Call Now
                       </a>
                    </div>
                    <div className="flex items-center gap-2 px-2">
                       <span className="w-2 h-2 rounded-full bg-slate-300"></span>
                       {dist.location}
                    </div>
                     <div className="flex items-center gap-2 px-2">
                       <span className={`w-2 h-2 rounded-full ${dist.isOnline ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-slate-300'}`}></span>
                       {dist.isOnline ? 'Available for Online Orders' : 'Offline / Call to Order'}
                    </div>
                  </div>

                  <a 
                    href={`tel:${dist.phone}`}
                    className="flex items-center justify-center gap-2 w-full bg-slate-50 border border-slate-200 text-slate-700 py-3 rounded-xl font-semibold hover:bg-orange-600 hover:text-white hover:border-orange-600 transition-all active:scale-95"
                  >
                    <PhoneIcon className="w-4 h-4" />
                    Call to Order
                  </a>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* --- Cart Sidebar --- */}
      {isCartOpen && (
        <>
           <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-40 transition-opacity" onClick={() => setIsCartOpen(false)}></div>
           <div className="fixed top-0 right-0 bottom-0 w-full max-w-md bg-white z-50 shadow-2xl flex flex-col animate-in slide-in-from-right duration-300">
             <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-white">
               <h2 className="text-2xl font-bold text-slate-900">Your Jhora (Basket)</h2>
               <button onClick={() => setIsCartOpen(false)} className="p-2 hover:bg-slate-100 rounded-full transition-colors text-slate-400 hover:text-slate-600">
                 <XIcon className="w-6 h-6" />
               </button>
             </div>

             {/* Cart Search and Filter Controls */}
             <div className="px-6 py-3 bg-slate-50 border-b border-slate-100 flex gap-2">
                <div className="relative flex-1">
                   <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                   <input 
                     type="text" 
                     placeholder="Search cart..." 
                     value={cartSearchQuery}
                     onChange={(e) => setCartSearchQuery(e.target.value)}
                     className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-orange-500 transition-colors"
                   />
                </div>
                <div className="relative w-1/3">
                   <select
                     value={cartDistributorFilter}
                     onChange={(e) => setCartDistributorFilter(e.target.value)}
                     className="w-full appearance-none pl-3 pr-8 py-2 bg-white border border-slate-200 rounded-lg text-sm text-slate-600 focus:outline-none focus:border-orange-500 transition-colors"
                   >
                     <option value="All">All</option>
                     {cartDistributors.map(d => (
                       <option key={d.id} value={d.id}>{d.name.split(' ')[0]}</option>
                     ))}
                   </select>
                   <ChevronDownIcon className="absolute right-2 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 pointer-events-none" />
                </div>
             </div>

             <div className="flex-1 overflow-y-auto p-6 space-y-6">
               {cart.length === 0 ? (
                 <div className="flex flex-col items-center justify-center h-full text-slate-400 space-y-4">
                    <div className="w-24 h-24 bg-orange-50 rounded-full flex items-center justify-center">
                        <ShoppingCartIcon className="w-10 h-10 opacity-20 text-orange-500" />
                    </div>
                    <p className="text-lg font-medium text-slate-600">Your basket is empty</p>
                    <button onClick={() => setIsCartOpen(false)} className="text-orange-600 font-bold hover:underline">Start Shopping</button>
                 </div>
               ) : (
                filteredCartItems.length === 0 ? (
                    <div className="text-center py-10 text-slate-500">
                        <p>No items match your search.</p>
                        <button onClick={() => { setCartSearchQuery(''); setCartDistributorFilter('All'); }} className="text-orange-600 text-sm font-semibold mt-2">Clear Cart Filters</button>
                    </div>
                ) : (
                 filteredCartItems.map(item => {
                   const activePrice = getItemPrice(item);
                   const isBulk = item.bulkThreshold && item.quantity >= item.bulkThreshold;
                   return (
                   <div key={item.id} className="flex gap-4 group">
                     <div className="w-20 h-20 rounded-xl overflow-hidden bg-slate-100 shrink-0 border border-slate-200 p-1">
                        <img src={item.image} alt={item.name} className="w-full h-full object-contain" />
                     </div>
                     <div className="flex-1 flex flex-col justify-between">
                       <div>
                           <h4 className="font-bold text-slate-900 leading-tight">{item.name}</h4>
                           <div className="flex items-center gap-2 mt-1">
                                <div className="flex items-center text-sm text-slate-500">
                                  <RupeeIcon className="w-3 h-3" />
                                  <span>{activePrice} / {item.unit}</span>
                                </div>
                                {isBulk && (
                                  <span className="text-[10px] bg-green-100 text-green-700 px-1.5 py-0.5 rounded font-bold">
                                    Bulk Applied
                                  </span>
                                )}
                           </div>
                       </div>
                       <div className="flex items-center gap-3">
                         <div className="flex items-center border border-slate-200 rounded-lg bg-slate-50">
                             <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-8 flex items-center justify-center hover:bg-white rounded-l-lg transition-colors text-slate-600 hover:text-orange-600 font-bold">-</button>
                             <input 
                                type="number" 
                                min="1"
                                value={item.quantity}
                                onChange={(e) => {
                                    const val = parseInt(e.target.value);
                                    if(!isNaN(val) && val >= 1) setItemQuantity(item.id, val);
                                }}
                                className="w-10 text-center text-sm bg-transparent font-semibold text-slate-900 focus:outline-none [-moz-appearance:_textfield] [&::-webkit-inner-spin-button]:m-0 [&::-webkit-inner-spin-button]:appearance-none"
                             />
                             <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-8 flex items-center justify-center hover:bg-white rounded-r-lg transition-colors text-slate-600 hover:text-orange-600 font-bold">+</button>
                         </div>
                         <div className="flex-1"></div>
                         <button onClick={() => removeFromCart(item.id)} className="text-xs text-red-500 hover:text-red-700 font-medium p-2 transition-colors">Remove</button>
                       </div>
                     </div>
                   </div>
                 )})
                )
               )}
             </div>

             {cart.length > 0 && (
               <div className="border-t border-slate-100 p-6 bg-slate-50 space-y-4">
                 <div className="flex justify-between text-lg font-bold text-slate-900 mb-2">
                   <span>Subtotal</span>
                   <span className="flex items-center"><RupeeIcon className="w-4 h-4" />{cartTotal}</span>
                 </div>
                 
                 <div className="grid grid-cols-1 gap-3">
                    <button className="w-full bg-orange-600 text-white py-3.5 rounded-xl font-bold text-lg hover:bg-orange-700 transition-all shadow-lg shadow-orange-500/20 active:scale-[0.98]">
                    Checkout Online
                    </button>
                    
                    <button 
                        onClick={() => {
                            setIsCartOpen(false);
                            setShowOfflineModal(true);
                        }}
                        className="w-full bg-white border-2 border-slate-200 text-slate-700 py-3.5 rounded-xl font-bold text-lg hover:border-slate-300 hover:bg-slate-50 transition-all active:scale-[0.98] flex items-center justify-center gap-2"
                    >
                        <PhoneIcon className="w-5 h-5" />
                        Order Offline (Call)
                    </button>
                 </div>
                 <p className="text-[10px] text-center text-slate-400 mt-2">
                    Connect directly to local distributors for best rates.
                 </p>
               </div>
             )}
           </div>
        </>
      )}

      {/* --- Offline Order Modal --- */}
      {showOfflineModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
           <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl animate-in fade-in zoom-in duration-200 max-h-[90vh] flex flex-col">
             <div className="p-6 border-b border-slate-100 flex justify-between items-center sticky top-0 bg-white rounded-t-3xl z-10">
                <div>
                    <h3 className="text-2xl font-bold text-slate-900">Offline Order (Call)</h3>
                    <p className="text-sm text-slate-500">Contact distributors directly to place your order.</p>
                </div>
                <button onClick={() => setShowOfflineModal(false)} className="p-2 hover:bg-slate-100 rounded-full bg-slate-50"><XIcon className="w-6 h-6" /></button>
             </div>
             
             <div className="p-6 overflow-y-auto space-y-6 bg-slate-50/50">
                {Object.keys(cartByDistributor).map(distId => {
                    const group = cartByDistributor[distId];
                    if (!group.distributor) return null;
                    return (
                        <div key={distId} className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm">
                            <div className="flex justify-between items-start mb-4 pb-4 border-b border-slate-100">
                                <div>
                                    <h4 className="font-bold text-lg text-slate-900">{group.distributor.name}</h4>
                                    <p className="text-xs text-slate-500">{group.distributor.location}</p>
                                </div>
                                <a 
                                    href={`tel:${group.distributor.phone}`}
                                    className="bg-green-600 text-white px-4 py-2 rounded-xl font-bold text-sm hover:bg-green-700 shadow-green-200 shadow-md flex items-center gap-2"
                                >
                                    <PhoneIcon className="w-4 h-4" />
                                    Call {group.distributor.phone}
                                </a>
                            </div>
                            <div className="space-y-2 mb-4">
                                {group.items.map(item => (
                                    <div key={item.id} className="flex justify-between text-sm">
                                        <span className="text-slate-600">{item.quantity} x {item.name}</span>
                                        <span className="font-medium text-slate-900 flex items-center"><RupeeIcon className="w-3 h-3" />{getItemPrice(item) * item.quantity}</span>
                                    </div>
                                ))}
                            </div>
                            <div className="flex justify-between items-center pt-2 border-t border-slate-100">
                                <span className="font-bold text-slate-700">Total</span>
                                <span className="font-bold text-orange-600 flex items-center"><RupeeIcon className="w-4 h-4" />{group.total}</span>
                            </div>
                        </div>
                    );
                })}
             </div>
             <div className="p-4 border-t border-slate-100 bg-white rounded-b-3xl">
                <button 
                    onClick={() => setShowOfflineModal(false)}
                    className="w-full bg-slate-100 text-slate-700 font-bold py-3 rounded-xl hover:bg-slate-200 transition-colors"
                >
                    Close
                </button>
             </div>
           </div>
        </div>
      )}

      {/* --- Add Distributor Modal --- */}
      {showAddDistributor && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
           <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl animate-in fade-in zoom-in duration-200">
             <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                <h3 className="text-xl font-bold text-slate-900">Add New Distributor</h3>
                <button onClick={() => setShowAddDistributor(false)} className="text-slate-400 hover:text-slate-600"><XIcon className="w-6 h-6" /></button>
             </div>
             <form onSubmit={handleAddDistributor} className="p-6 space-y-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Business Name</label>
                    <input 
                        required 
                        type="text" 
                        value={newDistName}
                        onChange={e => setNewDistName(e.target.value)}
                        className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all"
                        placeholder="e.g., Aggarwal Traders"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                    <input 
                        required 
                        type="tel" 
                        value={newDistPhone}
                        onChange={e => setNewDistPhone(e.target.value)}
                        className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all"
                        placeholder="+91 98765..."
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Location</label>
                    <input 
                        required 
                        type="text" 
                        value={newDistLocation}
                        onChange={e => setNewDistLocation(e.target.value)}
                        className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all"
                        placeholder="City / Market Area"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Specialty</label>
                    <input 
                        type="text" 
                        value={newDistSpecialty}
                        onChange={e => setNewDistSpecialty(e.target.value)}
                        className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all"
                        placeholder="e.g., Rice, Spices, General"
                    />
                </div>
                <div className="pt-2">
                    <button type="submit" className="w-full bg-orange-600 text-white font-bold py-3 rounded-xl hover:bg-orange-700 transition-colors shadow-lg shadow-orange-500/20">
                        Register Distributor
                    </button>
                </div>
             </form>
           </div>
        </div>
      )}

      {/* --- Edit Distributor Modal --- */}
      {editingDistributor && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
           <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl animate-in fade-in zoom-in duration-200">
             <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                <h3 className="text-xl font-bold text-slate-900">Edit Distributor</h3>
                <button onClick={() => setEditingDistributor(null)} className="text-slate-400 hover:text-slate-600"><XIcon className="w-6 h-6" /></button>
             </div>
             <form onSubmit={handleUpdateDistributor} className="p-6 space-y-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Business Name</label>
                    <input 
                        required 
                        type="text" 
                        value={editForm.name}
                        onChange={e => setEditForm({...editForm, name: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number</label>
                    <input 
                        required 
                        type="tel" 
                        value={editForm.phone}
                        onChange={e => setEditForm({...editForm, phone: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Location</label>
                    <input 
                        required 
                        type="text" 
                        value={editForm.location}
                        onChange={e => setEditForm({...editForm, location: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Specialty</label>
                    <input 
                        type="text" 
                        value={editForm.specialty}
                        onChange={e => setEditForm({...editForm, specialty: e.target.value})}
                        className="w-full px-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-orange-500 focus:border-orange-500 outline-none transition-all"
                    />
                </div>
                <div className="pt-2 flex gap-3">
                    <button 
                        type="button" 
                        onClick={() => setEditingDistributor(null)}
                        className="flex-1 bg-slate-100 text-slate-700 font-bold py-3 rounded-xl hover:bg-slate-200 transition-colors"
                    >
                        Cancel
                    </button>
                    <button type="submit" className="flex-1 bg-orange-600 text-white font-bold py-3 rounded-xl hover:bg-orange-700 transition-colors shadow-lg shadow-orange-500/20">
                        Save Changes
                    </button>
                </div>
             </form>
           </div>
        </div>
      )}

      {/* Floating AI Chef */}
      <AIChef products={PRODUCTS} />
    </div>
  );
};

export default App;