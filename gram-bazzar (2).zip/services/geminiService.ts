import { GoogleGenAI } from "@google/genai";
import { Product } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Helper for basic retry logic to handle transient 500/network errors
async function generateWithRetry(model: string, config: any, retries = 2) {
  for (let i = 0; i <= retries; i++) {
    try {
      const response = await ai.models.generateContent({
        model,
        ...config
      });
      return response;
    } catch (error) {
      if (i === retries) throw error;
      // Wait a bit before retrying (exponential backoff could be used here)
      await new Promise(res => setTimeout(res, 1000 * (i + 1)));
    }
  }
}

export const chatWithChef = async (
  history: { role: string; text: string }[],
  userMessage: string,
  products: Product[]
): Promise<string> => {
  try {
    // Include category in context for better pairing logic
    const productContext = products
      .map((p) => `- [${p.category}] ${p.name} (₹${p.price}/${p.unit}): ${p.description}`)
      .join("\n");

    const systemInstruction = `You are "Kirana Sahayak", a smart and friendly business assistant for the "Gram Bazzar" grocery community.
    
    **CORE OBJECTIVE:**
    Help customers find what they need and **always suggest complementary items** to complete their shopping list.
    
    **GUIDELINES:**
    1. **Smart Pairing**: If a user asks about a product, suggest logical companions from our inventory.
       - *Example*: User asks for "Dal" -> You suggest "Rice", "Ghee", and "Turmeric".
       - *Example*: User asks for "Tea" -> You suggest "Sugar", "Biscuits", or "Milk" (if available).
       - *Example*: User asks for "Soap" -> You suggest "Shampoo" or "Detergent".
    2. **Inventory Specific**: Only recommend items listed in the inventory below. If we don't have it, say so politely.
    3. **Cultural Touch**: Use warm, respectful Indian English (e.g., "Ji", "Madam", "Fresh stock").
    4. **Recipes**: If asked what to cook, suggest a dish using our ingredients.

    **GRAM BAZZAR INVENTORY:**
    ${productContext}
    
    Keep responses helpful, concise, and focused on helping the user build their basket.`;

    const model = 'gemini-2.5-flash';

    const response = await generateWithRetry(model, {
      contents: [
        ...history.map(msg => ({
            role: msg.role,
            parts: [{ text: msg.text }]
        })),
        { role: 'user', parts: [{ text: userMessage }] }
      ],
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    return response?.text || "Namaste! I am checking the stock register. One moment please.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "Maaf kijiye (Sorry), I am having trouble reaching the store server right now. Please try again in a moment.";
  }
};