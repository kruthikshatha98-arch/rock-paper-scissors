import { Distributor, Product } from './types';

export const INITIAL_DISTRIBUTORS: Distributor[] = [
  {
    id: 'd1',
    name: "Shree Ganesh Trading Co.",
    phone: "+91 98765 43210",
    location: "Sadar Bazaar, Delhi",
    rating: 4.9,
    specialty: "Wholesale Grains & Pulses",
    isOnline: true
  },
  {
    id: 'd2',
    name: "Laxmi General Suppliers",
    phone: "+91 99887 76655",
    location: "Dadar Market, Mumbai",
    rating: 4.7,
    specialty: "FMCG & Packaged Foods",
    isOnline: false
  },
  {
    id: 'd3',
    name: "Punjab Spice House",
    phone: "+91 91234 56789",
    location: "Khari Baoli",
    rating: 4.8,
    specialty: "Authentic Spices",
    isOnline: true
  },
  {
    id: 'd4',
    name: "South India Rice Depot",
    phone: "+91 98765 12345",
    location: "T. Nagar, Chennai",
    rating: 4.6,
    specialty: "Rice Varieties",
    isOnline: false
  },
  {
    id: 'd5',
    name: "Amulya Dairy & Sweets",
    phone: "+91 88990 01122",
    location: "Koramangala, Bangalore",
    rating: 4.8,
    specialty: "Dairy Products",
    isOnline: true
  }
];

// Helper to get accurate images resembling Google Images results
// We use a high-quality thumbnail service that searches for the exact product name
const getImg = (query: string) => {
  // Append 'indian grocery' or 'packet' to ensure we get product shots not generic generic nature photos
  const q = encodeURIComponent(`${query} indian grocery product packaging`);
  return `https://tse2.mm.bing.net/th?q=${q}&w=500&h=500&c=7&rs=1&p=0`;
};

export const PRODUCTS: Product[] = [
  // --- Existing Items ---
  { id: 'p1', name: "Sharbati Atta (10kg)", category: "Staples", price: 420, unit: "bag", image: getImg("Sharbati Atta 10kg bag"), description: "Premium quality whole wheat flour.", distributorId: 'd1', isFeatured: true, bulkThreshold: 5, bulkPrice: 400 },
  { id: 'p2', name: "Tata Salt", category: "Groceries", price: 28, unit: "pkt", image: getImg("Tata Salt packet"), description: "Iodized vacuum evaporated salt.", distributorId: 'd2', bulkThreshold: 20, bulkPrice: 25 },
  { id: 'p3', name: "India Gate Basmati Rice", category: "Rice", price: 850, unit: "5kg", image: getImg("India Gate Basmati Rice 5kg bag"), description: "Classic long grain aromatic basmati rice.", distributorId: 'd4', isFeatured: true, bulkThreshold: 3, bulkPrice: 810 },
  { id: 'p4', name: "Toor Dal (Arhar)", category: "Pulses", price: 160, unit: "kg", image: getImg("Toor Dal raw indian"), description: "Unpolished, protein-rich toor dal.", distributorId: 'd1', bulkThreshold: 10, bulkPrice: 150 },
  { id: 'p5', name: "Amul Pure Ghee", category: "Dairy", price: 540, unit: "1L", image: getImg("Amul Pure Ghee tetra pack"), description: "Pure cow ghee, rich aroma.", distributorId: 'd5', isFeatured: true, bulkThreshold: 6, bulkPrice: 520 },
  { id: 'p6', name: "Everest Turmeric Powder", category: "Spices", price: 45, unit: "100g", image: getImg("Everest Turmeric Powder box"), description: "Golden yellow turmeric.", distributorId: 'd3' },
  { id: 'p7', name: "Fortune Sunflower Oil", category: "Oil", price: 145, unit: "L", image: getImg("Fortune Sunflower Oil pouch"), description: "Refined sunflower oil.", distributorId: 'd2', bulkThreshold: 15, bulkPrice: 138 },
  { id: 'p8', name: "Red Chilli Powder", category: "Spices", price: 60, unit: "100g", image: getImg("MDH Red Chilli Powder"), description: "Spicy red chilli powder.", distributorId: 'd3' },
  { id: 'p9', name: "Maggi Noodles (4 Pack)", category: "Snacks", price: 56, unit: "pack", image: getImg("Maggi Noodles 4 pack"), description: "Classic masala noodles.", distributorId: 'd2', bulkThreshold: 12, bulkPrice: 52 },
  { id: 'p10', name: "Red Label Tea", category: "Beverages", price: 280, unit: "500g", image: getImg("Brooke Bond Red Label Tea box"), description: "Strong Indian CTC tea.", distributorId: 'd2' },

  // --- Staples & Flours (d1) ---
  { id: 'p11', name: "Chakki Fresh Atta", category: "Staples", price: 440, unit: "10kg", image: getImg("Aashirvaad Chakki Fresh Atta"), description: "Stone ground wheat flour.", distributorId: 'd1', bulkThreshold: 5, bulkPrice: 425 },
  { id: 'p12', name: "Maida (Refined Flour)", category: "Staples", price: 45, unit: "kg", image: getImg("Maida flour packet"), description: "Fine quality maida for baking.", distributorId: 'd1' },
  { id: 'p13', name: "Sooji (Semolina)", category: "Staples", price: 50, unit: "kg", image: getImg("Sooji packet indian"), description: "Granular sooji for halwa/upma.", distributorId: 'd1' },
  { id: 'p14', name: "Besan (Gram Flour)", category: "Staples", price: 90, unit: "kg", image: getImg("Fortune Besan packet"), description: "Fine besan for pakoras.", distributorId: 'd1' },
  { id: 'p15', name: "Ragi Flour", category: "Staples", price: 60, unit: "kg", image: getImg("Ragi flour packet"), description: "Healthy finger millet flour.", distributorId: 'd1' },
  { id: 'p16', name: "Bajra Flour", category: "Staples", price: 40, unit: "kg", image: getImg("Bajra flour packet"), description: "Pearl millet flour.", distributorId: 'd1' },
  { id: 'p17', name: "Jowar Flour", category: "Staples", price: 55, unit: "kg", image: getImg("Jowar flour packet"), description: "Sorghum flour, gluten free.", distributorId: 'd1' },
  { id: 'p18', name: "Corn Flour", category: "Staples", price: 40, unit: "500g", image: getImg("Corn flour box"), description: "Fine corn starch.", distributorId: 'd1' },
  { id: 'p19', name: "Makki Atta", category: "Staples", price: 45, unit: "kg", image: getImg("Makki ka atta packet"), description: "Yellow corn flour for rotis.", distributorId: 'd1' },
  { id: 'p20', name: "Multigrain Atta", category: "Staples", price: 320, unit: "5kg", image: getImg("Pillsbury Multigrain Atta"), description: "Blend of 7 grains.", distributorId: 'd1', bulkThreshold: 4, bulkPrice: 300 },

  // --- Rice & Rice Products (d4) ---
  { id: 'p21', name: "Kolam Rice", category: "Rice", price: 65, unit: "kg", image: getImg("Kolam Rice bag"), description: "Daily use medium grain rice.", distributorId: 'd4', bulkThreshold: 25, bulkPrice: 60 },
  { id: 'p22', name: "Sona Masoori Rice", category: "Rice", price: 58, unit: "kg", image: getImg("Sona Masoori Rice bag"), description: "Lightweight premium rice.", distributorId: 'd4' },
  { id: 'p23', name: "Idli Rice", category: "Rice", price: 45, unit: "kg", image: getImg("Idli Rice packet"), description: "Parboiled rice for batter.", distributorId: 'd4' },
  { id: 'p24', name: "Brown Rice", category: "Rice", price: 95, unit: "kg", image: getImg("Daawat Brown Rice"), description: "Whole grain healthy rice.", distributorId: 'd4' },
  { id: 'p25', name: "Poha (Thick)", category: "Rice", price: 50, unit: "kg", image: getImg("Thick Poha packet"), description: "Flattened rice for breakfast.", distributorId: 'd4' },
  { id: 'p26', name: "Poha (Thin)", category: "Rice", price: 52, unit: "kg", image: getImg("Thin Poha packet"), description: "Paper poha for chivda.", distributorId: 'd4' },
  { id: 'p27', name: "Murmura (Puffed Rice)", category: "Rice", price: 60, unit: "500g", image: getImg("Murmura packet"), description: "Crispy puffed rice.", distributorId: 'd4' },
  { id: 'p28', name: "Basmati Broken (Dubar)", category: "Rice", price: 70, unit: "kg", image: getImg("Basmati Rice Dubar bag"), description: "Broken basmati for daily use.", distributorId: 'd4' },
  { id: 'p29', name: "Jeera Samba Rice", category: "Rice", price: 85, unit: "kg", image: getImg("Seeraga Samba Rice bag"), description: "Short grain aromatic rice.", distributorId: 'd4' },
  { id: 'p30', name: "Red Matta Rice", category: "Rice", price: 75, unit: "kg", image: getImg("Kerala Matta Rice bag"), description: "Parboiled red rice.", distributorId: 'd4' },

  // --- Pulses & Dals (d1) ---
  { id: 'p31', name: "Moong Dal (Yellow)", category: "Pulses", price: 120, unit: "kg", image: getImg("Moong Dal washed packet"), description: "Split washed moong beans.", distributorId: 'd1' },
  { id: 'p32', name: "Moong Dal Chilka", category: "Pulses", price: 110, unit: "kg", image: getImg("Moong Dal Chilka packet"), description: "Split green moong with skin.", distributorId: 'd1' },
  { id: 'p33', name: "Whole Moong (Green)", category: "Pulses", price: 100, unit: "kg", image: getImg("Whole Moong Sabut packet"), description: "Whole green gram.", distributorId: 'd1' },
  { id: 'p34', name: "Masoor Dal (Red)", category: "Pulses", price: 95, unit: "kg", image: getImg("Masoor Dal Red packet"), description: "Split red lentils.", distributorId: 'd1' },
  { id: 'p35', name: "Masoor Whole (Black)", category: "Pulses", price: 90, unit: "kg", image: getImg("Whole Masoor Dal Black"), description: "Whole black lentils.", distributorId: 'd1' },
  { id: 'p36', name: "Urad Dal (White)", category: "Pulses", price: 140, unit: "kg", image: getImg("Urad Dal White Split"), description: "Washed black gram split.", distributorId: 'd1' },
  { id: 'p37', name: "Urad Dal Whole (Black)", category: "Pulses", price: 130, unit: "kg", image: getImg("Urad Dal Sabut Black"), description: "Whole black gram for makhani.", distributorId: 'd1' },
  { id: 'p38', name: "Chana Dal", category: "Pulses", price: 85, unit: "kg", image: getImg("Chana Dal packet"), description: "Split bengal gram.", distributorId: 'd1' },
  { id: 'p39', name: "Kabuli Chana (Big)", category: "Pulses", price: 150, unit: "kg", image: getImg("Kabuli Chana Dollar"), description: "Large white chickpeas.", distributorId: 'd1' },
  { id: 'p40', name: "Kala Chana (Small)", category: "Pulses", price: 80, unit: "kg", image: getImg("Kala Chana Small"), description: "Black chickpeas.", distributorId: 'd1' },
  { id: 'p41', name: "Rajma Chitra", category: "Pulses", price: 145, unit: "kg", image: getImg("Rajma Chitra packet"), description: "Speckled kidney beans.", distributorId: 'd1' },
  { id: 'p42', name: "Rajma Jammu (Red)", category: "Pulses", price: 160, unit: "kg", image: getImg("Rajma Jammu Red"), description: "Small dark red kidney beans.", distributorId: 'd1' },
  { id: 'p43', name: "Lobia (Black Eye)", category: "Pulses", price: 110, unit: "kg", image: getImg("Lobia Black Eyed Peas"), description: "Black eyed peas.", distributorId: 'd1' },
  { id: 'p44', name: "White Peas (Matar)", category: "Pulses", price: 75, unit: "kg", image: getImg("Safed Matar dry"), description: "Dry white peas for kulcha.", distributorId: 'd1' },
  { id: 'p45', name: "Soya Chunks", category: "Pulses", price: 45, unit: "200g", image: getImg("Nutrela Soya Chunks"), description: "High protein soya chunks.", distributorId: 'd1' },

  // --- Spices (d3) ---
  { id: 'p46', name: "Jeera (Cumin)", category: "Spices", price: 120, unit: "200g", image: getImg("Jeera Cumin Seeds packet"), description: "Premium whole cumin seeds.", distributorId: 'd3' },
  { id: 'p47', name: "Rai (Mustard Seeds)", category: "Spices", price: 30, unit: "100g", image: getImg("Black Mustard Seeds Rai"), description: "Small black mustard seeds.", distributorId: 'd3' },
  { id: 'p48', name: "Coriander Powder", category: "Spices", price: 40, unit: "200g", image: getImg("Dhania Powder packet"), description: "Aromatic dhania powder.", distributorId: 'd3' },
  { id: 'p49', name: "Garam Masala", category: "Spices", price: 85, unit: "100g", image: getImg("Everest Garam Masala"), description: "Blend of hot spices.", distributorId: 'd3' },
  { id: 'p50', name: "Kitchen King Masala", category: "Spices", price: 75, unit: "100g", image: getImg("MDH Kitchen King Masala"), description: "All purpose curry masala.", distributorId: 'd3' },
  { id: 'p51', name: "Chaat Masala", category: "Spices", price: 60, unit: "100g", image: getImg("MDH Chaat Masala"), description: "Tangy spice blend.", distributorId: 'd3' },
  { id: 'p52', name: "Chicken Masala", category: "Spices", price: 70, unit: "100g", image: getImg("Everest Chicken Masala"), description: "Spice mix for chicken curry.", distributorId: 'd3' },
  { id: 'p53', name: "Sabji Masala", category: "Spices", price: 55, unit: "100g", image: getImg("Sabji Masala packet"), description: "Enhances vegetable dishes.", distributorId: 'd3' },
  { id: 'p54', name: "Kashmiri Chilli Powder", category: "Spices", price: 110, unit: "100g", image: getImg("Kashmiri Chilli Powder"), description: "For vibrant red colour.", distributorId: 'd3' },
  { id: 'p55', name: "Black Pepper Whole", category: "Spices", price: 150, unit: "100g", image: getImg("Black Pepper Whole Kali Mirch"), description: "Spicy peppercorns.", distributorId: 'd3' },
  { id: 'p56', name: "Cardamom Green", category: "Spices", price: 350, unit: "50g", image: getImg("Green Cardamom Elaichi packet"), description: "Aromatic green pods.", distributorId: 'd3' },
  { id: 'p57', name: "Cloves (Laung)", category: "Spices", price: 120, unit: "50g", image: getImg("Cloves Laung packet"), description: "Whole cloves.", distributorId: 'd3' },
  { id: 'p58', name: "Cinnamon Sticks", category: "Spices", price: 80, unit: "50g", image: getImg("Cinnamon Sticks Dalchini"), description: "Dalchini bark.", distributorId: 'd3' },
  { id: 'p59', name: "Hing (Asafoetida)", category: "Spices", price: 140, unit: "50g", image: getImg("LG Hing bottle"), description: "Strong compounded hing.", distributorId: 'd3' },
  { id: 'p60', name: "Kasuri Methi", category: "Spices", price: 45, unit: "50g", image: getImg("MDH Kasuri Methi box"), description: "Dried fenugreek leaves.", distributorId: 'd3' },

  // --- Oil & Ghee (d2 & d5) ---
  { id: 'p61', name: "Mustard Oil (Kachi Ghani)", category: "Oil", price: 165, unit: "L", image: getImg("Fortune Mustard Oil Bottle"), description: "Pungent mustard oil.", distributorId: 'd2' },
  { id: 'p62', name: "Soybean Oil", category: "Oil", price: 135, unit: "L", image: getImg("Soybean Oil pouch"), description: "Refined soyabean oil.", distributorId: 'd2' },
  { id: 'p63', name: "Groundnut Oil", category: "Oil", price: 190, unit: "L", image: getImg("Groundnut Oil bottle"), description: "Filtered peanut oil.", distributorId: 'd2' },
  { id: 'p64', name: "Rice Bran Oil", category: "Oil", price: 155, unit: "L", image: getImg("Fortune Rice Bran Oil"), description: "Heart healthy oil.", distributorId: 'd2' },
  { id: 'p65', name: "Olive Oil (Pomace)", category: "Oil", price: 650, unit: "L", image: getImg("Figaro Olive Oil tin"), description: "For indian cooking.", distributorId: 'd2' },
  { id: 'p66', name: "Vanaspati Ghee", category: "Oil", price: 110, unit: "L", image: getImg("Dalda Vanaspati Ghee"), description: "Hydrogenated vegetable fat.", distributorId: 'd2' },
  { id: 'p67', name: "Buffalo Ghee", category: "Dairy", price: 600, unit: "L", image: getImg("Buffalo Ghee jar"), description: "Rich granular ghee.", distributorId: 'd5' },
  { id: 'p68', name: "Amul Butter", category: "Dairy", price: 54, unit: "100g", image: getImg("Amul Butter 100g"), description: "Salted yellow butter.", distributorId: 'd5' },
  { id: 'p69', name: "Cheese Slices", category: "Dairy", price: 145, unit: "200g", image: getImg("Amul Cheese Slices"), description: "Processed cheese slices.", distributorId: 'd5' },
  { id: 'p70', name: "Paneer (Fresh)", category: "Dairy", price: 90, unit: "200g", image: getImg("Amul Malai Paneer"), description: "Soft malai paneer.", distributorId: 'd5' },

  // --- Dry Fruits (d3) ---
  { id: 'p71', name: "Almonds (Badam)", category: "Dry Fruits", price: 850, unit: "kg", image: getImg("Almonds Badam packet"), description: "California almonds.", distributorId: 'd3', isFeatured: true, bulkThreshold: 3, bulkPrice: 800 },
  { id: 'p72', name: "Cashews (Kaju)", category: "Dry Fruits", price: 900, unit: "kg", image: getImg("Cashew Nuts Kaju"), description: "Whole white cashews.", distributorId: 'd3' },
  { id: 'p73', name: "Raisins (Kishmish)", category: "Dry Fruits", price: 350, unit: "kg", image: getImg("Raisins Kishmish"), description: "Sweet indian raisins.", distributorId: 'd3' },
  { id: 'p74', name: "Walnuts (Akhrot)", category: "Dry Fruits", price: 1200, unit: "kg", image: getImg("Walnuts Akhrot Giri"), description: "In-shell walnuts.", distributorId: 'd3' },
  { id: 'p75', name: "Pistachios (Pista)", category: "Dry Fruits", price: 1400, unit: "kg", image: getImg("Pistachios Roasted Salted"), description: "Salted roasted pista.", distributorId: 'd3' },
  { id: 'p76', name: "Dates (Khajoor)", category: "Dry Fruits", price: 250, unit: "500g", image: getImg("Lion Dates packet"), description: "Premium arabian dates.", distributorId: 'd3' },
  { id: 'p77', name: "Makhana (Fox Nuts)", category: "Dry Fruits", price: 600, unit: "kg", image: getImg("Phool Makhana packet"), description: "Crispy lotus seeds.", distributorId: 'd3' },

  // --- Sugar & Salt (d2) ---
  { id: 'p78', name: "Sugar (M-30)", category: "Groceries", price: 44, unit: "kg", image: getImg("Madhur Sugar packet"), description: "White crystal sugar.", distributorId: 'd2', bulkThreshold: 10, bulkPrice: 40 },
  { id: 'p79', name: "Jaggery (Gud)", category: "Groceries", price: 60, unit: "kg", image: getImg("Jaggery Gud block"), description: "Chemical free jaggery block.", distributorId: 'd2' },
  { id: 'p80', name: "Jaggery Powder", category: "Groceries", price: 75, unit: "kg", image: getImg("Jaggery Powder packet"), description: "Shakkar powder.", distributorId: 'd2' },
  { id: 'p81', name: "Rock Salt (Sendha)", category: "Groceries", price: 45, unit: "kg", image: getImg("Sendha Namak packet"), description: "Pure himalayan pink salt.", distributorId: 'd2' },
  { id: 'p82', name: "Black Salt", category: "Groceries", price: 30, unit: "200g", image: getImg("Kala Namak Catch Sprinkler"), description: "Tangy kala namak.", distributorId: 'd2' },

  // --- Snacks & Breakfast (d2) ---
  { id: 'p83', name: "Parle-G", category: "Snacks", price: 10, unit: "pack", image: getImg("Parle-G Gold"), description: "Glucose biscuits.", distributorId: 'd2' },
  { id: 'p84', name: "Marie Gold", category: "Snacks", price: 35, unit: "pack", image: getImg("Britannia Marie Gold"), description: "Tea time biscuits.", distributorId: 'd2' },
  { id: 'p85', name: "Good Day Cashew", category: "Snacks", price: 40, unit: "pack", image: getImg("Britannia Good Day Cashew"), description: "Butter cashew cookies.", distributorId: 'd2' },
  { id: 'p86', name: "Namkeen Aloo Bhujia", category: "Snacks", price: 55, unit: "200g", image: getImg("Haldiram Aloo Bhujia"), description: "Spicy potato noodles.", distributorId: 'd2' },
  { id: 'p87', name: "Rusk (Suaji Toast)", category: "Snacks", price: 45, unit: "pack", image: getImg("Britannia Rusk"), description: "Crunchy tea toast.", distributorId: 'd2' },
  { id: 'p88', name: "Tomato Ketchup", category: "Snacks", price: 110, unit: "1kg", image: getImg("Kissan Tomato Ketchup bottle"), description: "Sweet tomato sauce.", distributorId: 'd2' },
  { id: 'p89', name: "Mixed Fruit Jam", category: "Snacks", price: 120, unit: "500g", image: getImg("Kissan Mixed Fruit Jam jar"), description: "Fruity breakfast spread.", distributorId: 'd2' },
  { id: 'p90', name: "Dabur Honey", category: "Groceries", price: 190, unit: "500g", image: getImg("Dabur Honey Squeeze"), description: "Pure honey.", distributorId: 'd2' },
  { id: 'p91', name: "Quaker Oats", category: "Groceries", price: 95, unit: "500g", image: getImg("Quaker Oats packet"), description: "Whole grain oats.", distributorId: 'd2' },
  { id: 'p92', name: "Kellogg's Cornflakes", category: "Groceries", price: 180, unit: "475g", image: getImg("Kelloggs Cornflakes box"), description: "Crunchy corn flakes.", distributorId: 'd2' },

  // --- Beverages (d2) ---
  { id: 'p93', name: "Taj Mahal Tea", category: "Beverages", price: 380, unit: "500g", image: getImg("Brooke Bond Taj Mahal Tea"), description: "Premium tea leaves.", distributorId: 'd2' },
  { id: 'p94', name: "Green Tea Bags", category: "Beverages", price: 160, unit: "25s", image: getImg("Lipton Green Tea Box"), description: "Healthy green tea.", distributorId: 'd2' },
  { id: 'p95', name: "Nescafe Instant Coffee", category: "Beverages", price: 190, unit: "50g", image: getImg("Nescafe Classic Coffee Jar"), description: "Aromatic instant coffee.", distributorId: 'd2' },
  { id: 'p96', name: "Bru Filter Coffee", category: "Beverages", price: 110, unit: "200g", image: getImg("Bru Green Label Coffee"), description: "Chicory blend.", distributorId: 'd2' },
  { id: 'p97', name: "Bournvita", category: "Beverages", price: 290, unit: "500g", image: getImg("Cadbury Bournvita Jar"), description: "Malt based milk additive.", distributorId: 'd2' },
  { id: 'p98', name: "Maaza Mango", category: "Beverages", price: 110, unit: "1L", image: getImg("Maaza Mango Drink Bottle"), description: "Thick mango pulp drink.", distributorId: 'd2' },

  // --- Personal Care (d2) ---
  { id: 'p99', name: "Lux Soap", category: "Personal Care", price: 40, unit: "bar", image: getImg("Lux Soap Pink"), description: "Moisturizing bar soap.", distributorId: 'd2', bulkThreshold: 12, bulkPrice: 35 },
  { id: 'p100', name: "Dettol Soap", category: "Personal Care", price: 35, unit: "bar", image: getImg("Dettol Original Soap"), description: "Germ protection soap.", distributorId: 'd2' },
  { id: 'p101', name: "Sunsilk Shampoo", category: "Personal Care", price: 180, unit: "340ml", image: getImg("Sunsilk Black Shampoo Bottle"), description: "Shine and strength.", distributorId: 'd2' },
  { id: 'p102', name: "Colgate Salt", category: "Personal Care", price: 110, unit: "200g", image: getImg("Colgate Active Salt Toothpaste"), description: "Active salt toothpaste.", distributorId: 'd2' },
  { id: 'p103', name: "Parachute Coconut Oil", category: "Personal Care", price: 95, unit: "200ml", image: getImg("Parachute Coconut Oil Bottle"), description: "Pure coconut oil.", distributorId: 'd2' },
  { id: 'p104', name: "Himalaya Face Wash", category: "Personal Care", price: 140, unit: "100g", image: getImg("Himalaya Neem Face Wash"), description: "Neem face wash.", distributorId: 'd2' },

  // --- Household (d2) ---
  { id: 'p105', name: "Surf Excel", category: "Household", price: 130, unit: "kg", image: getImg("Surf Excel Easy Wash"), description: "Stain removal powder.", distributorId: 'd2' },
  { id: 'p106', name: "Vim Bar", category: "Household", price: 20, unit: "bar", image: getImg("Vim Dishwash Bar"), description: "Lemon dish bar.", distributorId: 'd2', bulkThreshold: 12, bulkPrice: 18 },
  { id: 'p107', name: "Vim Liquid", category: "Household", price: 105, unit: "500ml", image: getImg("Vim Dishwash Liquid Bottle"), description: "Gel dish cleaner.", distributorId: 'd2' },
  { id: 'p108', name: "Lizol Floor Cleaner", category: "Household", price: 180, unit: "1L", image: getImg("Lizol Floor Cleaner"), description: "Pine disinfectant.", distributorId: 'd2' },
  { id: 'p109', name: "Harpic", category: "Household", price: 95, unit: "500ml", image: getImg("Harpic Toilet Cleaner Blue"), description: "Thick bleach cleaner.", distributorId: 'd2' },
  { id: 'p110', name: "Cycle Agarbatti", category: "Household", price: 40, unit: "pack", image: getImg("Cycle Pure Agarbatti"), description: "Rose scented sticks.", distributorId: 'd2' },
  { id: 'p111', name: "Homelites Matches", category: "Household", price: 10, unit: "pack", image: getImg("Homelites Matchbox"), description: "Pack of 5 boxes.", distributorId: 'd2', bulkThreshold: 10, bulkPrice: 8 },
];